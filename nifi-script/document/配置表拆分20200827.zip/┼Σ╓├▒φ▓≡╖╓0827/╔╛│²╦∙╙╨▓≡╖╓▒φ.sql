DROP TABLE tstream_rule;
DROP TABLE tstream_rule_alarm ;
DROP TABLE tstream_rule_calculation ;
DROP TABLE tstream_rule_collection ;
DROP TABLE tstream_rule_other_distributions ;
DROP TABLE tstream_rule_shore_based_distributions ;
DROP TABLE tstream_rule_thinning ;
DROP TABLE tstream_rule_warehousing ;