delimiter //  # 定义//为一句sql的结束标志，取消;的所代表的意义
drop procedure if exists test;  # 如果存在名字为test的procedure则删除
create procedure test()  # 创建（创建函数使用的关键字为function 函数名()）
begin
		# 声明变量
		declare tcolfreq varchar(255);
		declare tcolinterval varchar(255);
		declare tdistfreq varchar(255);
		declare ttoshorefreq varchar(255);
		declare tsparseRate VARCHAR(255);
		declare truleid int;
    declare flag int default 0; # 定义循环结果的标志位
 		declare freq double(10,2); # 定义分割特殊字段的暂存字段
    # 将查询结果赋值给游标
    declare tstream_rule cursor for select ruleid,colfreq,colinterval,distfreq,toshorefreq,sparseRate from tstream_rule_copy;
    # 为下面while循环建立一个退出标志，当游标遍历完后将flag的值设置为1
    declare continue handler for not found set flag=1;
    open tstream_rule;  # 打开游标
    # 将游标中的值赋给定义好的变量，实现for循环的要点
        fetch tstream_rule into truleid,tcolfreq,tcolinterval,tdistfreq,ttoshorefreq,tsparseRate;
        while flag <> 1 do
						# tcolfreq
						IF (LOCATE(",",tcolfreq)>0) then
							#得到第一个分割字段
							set freq = substring_index(tcolfreq, ",", 1);
							#得到剩余的分割字段
 							set @temp_freq_end = SUBSTRING(tcolfreq,LOCATE(",",tcolfreq)+1);
 							IF (LOCATE("ms",@temp_freq_end)>0) THEN
 								set freq = freq/1000;
 							ELSEIF (LOCATE("m",@temp_freq_end)>0) THEN
 								set freq = freq*60;
 						  ELSEIF (LOCATE("h",@temp_freq_end)>0) THEN
 								set freq = freq*3600;
 							ELSEIF (LOCATE("d",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24;
 							ELSEIF (LOCATE("w",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24*7;
 							end if;
							# 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							update tstream_rule_copy set colfreq=freq where ruleid = truleid;
							set freq = 0;
						end if;
#           tcolinterval
						IF (LOCATE(",",tcolinterval)>0) then
							#得到第一个分割字段
							set freq = substring_index(tcolinterval, ",", 1);
							#得到剩余的分割字段
 							set @temp_freq_end = SUBSTRING(tcolinterval,LOCATE(",",tcolinterval)+1);
 							IF (LOCATE("ms",@temp_freq_end)>0) THEN
 								set freq = freq/1000;
 							ELSEIF (LOCATE("m",@temp_freq_end)>0) THEN
 								set freq = freq*60;
 							ELSEIF (LOCATE("h",@temp_freq_end)>0) THEN
 								set freq = freq*3600;
 							ELSEIF (LOCATE("d",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24;
 							ELSEIF (LOCATE("w",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24*7;
 							end if;
							# 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							update tstream_rule_copy set colinterval=freq where ruleid = truleid;
							set freq = 0;
						end if;
#           tdistfreq
						IF (LOCATE(",",tdistfreq)>0) then
							#得到第一个分割字段
							set freq = substring_index(tdistfreq, ",", 1);
							#得到剩余的分割字段
 							set @temp_freq_end = SUBSTRING(tdistfreq,LOCATE(",",tdistfreq)+1);
 							IF (LOCATE("ms",@temp_freq_end)>0) THEN
 								set freq = freq/1000;
 							ELSEIF (LOCATE("m",@temp_freq_end)>0) THEN
 								set freq = freq*60;
 							ELSEIF (LOCATE("h",@temp_freq_end)>0) THEN
 								set freq = freq*3600;
 							ELSEIF (LOCATE("d",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24;
 							ELSEIF (LOCATE("w",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24*7;
 							end if;
							# 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							update tstream_rule_copy set distfreq=freq where ruleid = truleid;
							set freq = 0;
						end if;
#           ttoshorefreq
						IF (LOCATE(",",ttoshorefreq)>0) then
							#得到第一个分割字段
							set freq = substring_index(ttoshorefreq, ",", 1);
							#得到剩余的分割字段
 							set @temp_freq_end = SUBSTRING(ttoshorefreq,LOCATE(",",ttoshorefreq)+1);
 							IF (LOCATE("ms",@temp_freq_end)>0) THEN
 								set freq = freq/1000;
 							ELSEIF (LOCATE("m",@temp_freq_end)>0) THEN
 								set freq = freq*60;
 							ELSEIF (LOCATE("h",@temp_freq_end)>0) THEN
 								set freq = freq*3600;
 							ELSEIF (LOCATE("d",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24;
 							ELSEIF (LOCATE("w",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24*7;
 							end if;
							# 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							update tstream_rule_copy set toshorefreq=freq where ruleid = truleid;
							set freq = 0;
						end if;
#           tsparseRate
						IF (LOCATE(",",tsparseRate)>0) then
							#得到第一个分割字段
							set freq = substring_index(tsparseRate, ",", 1);
							#得到剩余的分割字段
 							set @temp_freq_end = SUBSTRING(tsparseRate,LOCATE(",",tsparseRate)+1);
 							IF (LOCATE("ms",@temp_freq_end)>0) THEN
 								set freq = freq/1000;
 							ELSEIF (LOCATE("m",@temp_freq_end)>0) THEN
 								set freq = freq*60;
 							ELSEIF (LOCATE("h",@temp_freq_end)>0) THEN
 								set freq = freq*3600;
 							ELSEIF (LOCATE("d",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24;
 							ELSEIF (LOCATE("w",@temp_freq_end)>0) THEN
 								set freq = freq*3600*24*7;
 							end if;
							# 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							update tstream_rule_copy set sparseRate=freq where ruleid = truleid;
							set freq = 0;
						end if;
							# 游标往后移
							fetch tstream_rule into truleid,tcolfreq,tcolinterval,tdistfreq,ttoshorefreq,tsparseRate;
        end while;
        #select * from temp_table;
    close tstream_rule;  # 关闭游标
end
//
delimiter ;  # 重新定义;为一句sql的结束标志，取消//的所代表的意义
call test(); # 调用
select ruleid,colfreq,colinterval,distfreq,toshorefreq,sparseRate from tstream_rule_copy; # 测试结果
-- update tstream_rule_copy set colinterval = "400,ms";