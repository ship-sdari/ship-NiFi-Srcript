delimiter //  # 定义//为一句sql的结束标志，取消;的所代表的意义
drop procedure if exists test;  # 如果存在名字为test的procedure则删除
create procedure test()  # 创建（创建函数使用的关键字为function 函数名()）
begin
		# 声明变量
		declare tcompress_type varchar(255);
		declare tto_shore_protocol varchar(255);
		declare tto_shore_ip_addr varchar(255);
		declare tto_shore_group varchar(255);
		declare tto_shore_freq varchar(255);
		declare tdoss_key int;
		declare tid int;
		declare tsid int;
    declare flag int default 0; # 定义循环结果的标志位
		declare str VARCHAR(255); # 定义分割特殊字段的暂存字段
    # 将查询结果赋值给游标
    declare tstream_rule cursor for select id,sid,doss_key,to_shore_freq,to_shore_group,to_shore_ip,to_shore_protocol,compress_type from tstream_rule_shore_based_distributions; 
    # 为下面while循环建立一个退出标志，当游标遍历完后将flag的值设置为1
    declare continue handler for not found set flag=1;
    open tstream_rule;  # 打开游标
    # 将游标中的值赋给定义好的变量，实现for循环的要点
        fetch tstream_rule into tid,tsid,tdoss_key,tto_shore_freq,tto_shore_group,tto_shore_ip_addr,tto_shore_protocol,tcompress_type;
        while flag <> 1 do
						# 在T-SQL中，局部变量必须以@作为前缀，声明方式set，select还有点差别
						IF (LOCATE(",",tto_shore_ip_addr)>0) THEN
							 #得到第一个分割字段
							 set @temp_ip = SUBSTRING_INDEX(tto_shore_ip_addr,",",1);
							 #得到剩余的分割字段
							 set @temp_port = SUBSTRING(tto_shore_ip_addr,LOCATE(",",tto_shore_ip_addr)+1);
							 # 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							 update tstream_rule_shore_based_distributions set to_shore_ip=@temp_ip,to_shore_port=@temp_port where id = tid and sid = tsid;
						END IF;
							# 游标往后移
							fetch tstream_rule into tid,tsid,tdoss_key,tto_shore_freq,tto_shore_group,tto_shore_ip_addr,tto_shore_protocol,tcompress_type;
        end while;
        #select * from temp_table;
    close tstream_rule;  # 关闭游标
end
//
delimiter ;  # 重新定义;为一句sql的结束标志，取消//的所代表的意义
call test(); # 调用
select * from tstream_rule_shore_based_distributions; # 测试结果
