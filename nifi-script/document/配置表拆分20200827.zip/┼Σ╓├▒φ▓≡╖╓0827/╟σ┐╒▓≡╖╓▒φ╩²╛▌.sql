TRUNCATE TABLE tstream_rule;
TRUNCATE TABLE tstream_rule_alarm ;
TRUNCATE TABLE tstream_rule_calculation ;
TRUNCATE TABLE tstream_rule_collection ;
TRUNCATE TABLE tstream_rule_other_distributions ;
TRUNCATE TABLE tstream_rule_shore_based_distributions ;
TRUNCATE TABLE tstream_rule_thinning ;
TRUNCATE TABLE tstream_rule_warehousing ;