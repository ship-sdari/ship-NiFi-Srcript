SET FOREIGN_KEY_CHECKS = 0;
-- ----------------------------
-- 流规则配置基本表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule`;
CREATE TABLE `tstream_rule` (
	`rule_id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '配置规则号',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`ship_id` VARCHAR ( 100 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '船舶ID',
	`sys_id` SMALLINT ( 6 ) NOT NULL DEFAULT '0' COMMENT '系统ID',
	`cat_id` SMALLINT ( 6 ) NOT NULL DEFAULT '0' COMMENT '信号分组分表编号',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`protocol` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '通讯协议',
	`name_chn` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '信号中文名',
	`name_eng` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '信号英文名',
	`orig_key` VARCHAR ( 155 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '原始key值',
	`data_from` VARCHAR ( 50 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '数据来源标志位',
	`unit` VARCHAR ( 20 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '单位',
	`transfer_factor` DECIMAL ( 20, 10 ) NOT NULL DEFAULT '1.0000000000' COMMENT '量纲转换因子',
	`coefficient` DECIMAL ( 20, 10 ) NOT NULL DEFAULT '1.0000000000' COMMENT '系数',
	`status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '信号启用状态 A-开启 S-禁用 D-删除',
	`value_type` VARCHAR ( 20 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '-' COMMENT '开关量/模拟量-T/A',
	`value_min` DECIMAL ( 20, 10 ) COMMENT '量程最小值',
	`value_max` DECIMAL ( 20, 10 ) COMMENT '量程最大值',
	`inner_key` VARCHAR ( 100 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '应用名称',
	`input_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '插入时间',
	`input_user` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'NIFI' COMMENT '插入用户',
	`last_modify_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
	`last_modify_user` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'NIFI' COMMENT '最后修改用户',
	PRIMARY KEY ( `rule_id` ),
	UNIQUE INDEX `key1` ( `sid`, `doss_key` ) USING BTREE,
	INDEX `key2` ( `ship_id`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置基本表';
-- ----------------------------
-- 流规则配置报警表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_alarm`;
CREATE TABLE `tstream_rule_alarm` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`alert_min` DECIMAL ( 20, 10 ) COMMENT '报警最小值',
	`alert_2nd_min` DECIMAL ( 20, 10 ) COMMENT '报警次小值',
	`alert_2nd_max` DECIMAL ( 20, 10 ) COMMENT '报警次大值',
	`alert_max` DECIMAL ( 20, 10 ) COMMENT '报警最大值',
	`relate_stop_sig` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '关联设备状态标志位',
	`alert_status` VARCHAR ( 1 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '报警启用状态字段 A-开启 S-禁用 D-删除',
	`is_popup` VARCHAR ( 10 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '报警是否弹窗 A-开启 S-禁用',
	`ams_alarm_standard` INT ( 1 ) COMMENT 'ams开关量报警标志',
	`alert_way` VARCHAR ( 10 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'R' COMMENT '报警方式 R-实时报警 W-窗口报警',
	PRIMARY KEY ( `id` ),
	INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置报警表';
-- ----------------------------
-- 流规则配置计算表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_calculation`;
CREATE TABLE `tstream_rule_calculation` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`calculation_key` VARCHAR ( 100 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '参与指标计算所转换的key值,与计算程序中保持一致,通常使用inner_key即可',
	`formula_flag` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '指标名称标志位',
	`calculation_status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '启用状态 A-开启 S-禁用 D-删除',
	PRIMARY KEY ( `id` ),
	INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置计算表';
-- ----------------------------
-- 流规则配置采集表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_collection`;
CREATE TABLE `tstream_rule_collection` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`colgroup` VARCHAR ( 50 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '采集组编号',
	`modbus_slave_id` INT ( 11 ) COMMENT '从站编号',
	`modbus_func_id` SMALLINT ( 6 ) NOT NULL COMMENT 'modbus操作功能',
	`addr` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '地址',
	`ip_addr` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '数据来源IP地址',
	`port_addr` VARCHAR ( 255 ) COMMENT '端口地址',
	`from_table_id` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '来源表名',
	`from_column_id` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '来源列名',
	`protocol` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '通讯协议',
	`col_freq` DOUBLE ( 10, 2 ) NOT NULL DEFAULT '1.00' COMMENT '采样频率,默认单位-秒',
	`topic` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '主题名称',
	`modbus_sig_tag` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT 'Modbus信号标签',
	`col_interval` DOUBLE ( 10, 2 ) COMMENT '抓包间隔,默认单位-秒',
	`col_count` INT ( 11 ) COMMENT '抓包次数',
	`nmea_id` BIGINT ( 20 ) DEFAULT NULL COMMENT 'nmea0183_config关联id',
	`collection_status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '启用状态 A-开启 S-禁用 D-删除',
	PRIMARY KEY ( `id` ),
	INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置采集表';
-- ----------------------------
-- 流规则配置第三方分发表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_other_distributions`;
CREATE TABLE `tstream_rule_other_distributions` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`dist_group` VARCHAR ( 10 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '数据分发分组',
	`dist_ip` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '数据分发目的IP',
	`dist_port` INT ( 10 ) NOT NULL DEFAULT '0000' COMMENT '数据分发目的port',
	`dist_freq` DOUBLE ( 10, 2 ) NOT NULL DEFAULT '1.00' COMMENT '数据分发频率,默认单位-秒',
	`dist_protocol` VARCHAR ( 50 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '数据分发协议',
	`dist_user_and_password` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '用于分发的用户名和密码',
	`dist_status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '分发启用状态 A-开启 S-禁用 D-删除',
	PRIMARY KEY ( `id` ),
	INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置第三方分发表';
-- ----------------------------
-- 流规则配置岸基分发表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_shore_based_distributions`;
CREATE TABLE `tstream_rule_shore_based_distributions` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`to_shore_group` VARCHAR ( 20 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL COMMENT '船岸传输组',
	`to_shore_ip` VARCHAR ( 200 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '船岸传输目的IP',
	`to_shore_port` INT ( 10 ) NOT NULL DEFAULT '0000' COMMENT '船岸传输目的port',
	`to_shore_freq` DOUBLE ( 10, 2 ) NOT NULL DEFAULT '300.00' COMMENT '船岸传输频率,默认单位-秒',
	`to_shore_protocol` VARCHAR ( 50 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '船岸传输协议',
	`compress_type` VARCHAR ( 50 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '船岸传输压缩方式',
	`to_shore_status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '分发启用状态 A-开启 S-禁用 D-删除',
	PRIMARY KEY ( `id` ),
	INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置岸基分发表';
-- ----------------------------
-- 流规则配置抽稀表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_thinning`;
CREATE TABLE `tstream_rule_thinning` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`sparse_rate` INT ( 10 ) NOT NULL DEFAULT '60' COMMENT '抽稀频率,默认单位-秒',
	`dilution_type` INT ( 1 ) NOT NULL DEFAULT '3' COMMENT '1.求累计 2.求平均 3.只取点',
	`dilution_status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '启用状态 A-开启 S-禁用 D-删除',
	PRIMARY KEY ( `id` ),
	INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置抽稀表';
-- ----------------------------
-- 流规则配置入库表
-- ----------------------------
DROP TABLE
IF
	EXISTS `tstream_rule_warehousing`;
CREATE TABLE `tstream_rule_warehousing` (
	`id` INT ( 11 ) NOT NULL AUTO_INCREMENT COMMENT '',
	`sid` INT ( 11 ) NOT NULL COMMENT '船ID',
	`doss_key` INT ( 11 ) NOT NULL COMMENT 'DOSS系统key值(自定义值)',
	`schema_id` VARCHAR ( 100 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '入库库名',
	`table_id` VARCHAR ( 255 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '数据表名',
	`column_id` VARCHAR ( 50 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT '列名',
	`data_type` VARCHAR ( 20 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'varchar(255)' COMMENT '数据类型',
	`write_status` VARCHAR ( 2 ) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'S' COMMENT '启用状态 A-开启 S-禁用 D-删除',
	PRIMARY KEY ( `id` ),
INDEX `key1` ( `sid`, `doss_key` ) USING BTREE 
) ENGINE = INNODB AUTO_INCREMENT = 58130 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT '流规则配置入库表';