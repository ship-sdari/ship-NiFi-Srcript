alter TABLE ship_1.t_alarm_history ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_1.t_alarm_real ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_1.t_alarm_shield ADD dossKey VARCHAR(255) not null DEFAULT '-';

alter TABLE ship_2.t_alarm_history ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_2.t_alarm_real ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_2.t_alarm_shield ADD dossKey VARCHAR(255) not null DEFAULT '-';

alter TABLE ship_47.t_alarm_history ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_47.t_alarm_real ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_47.t_alarm_shield ADD dossKey VARCHAR(255) not null DEFAULT '-';

alter TABLE ship_48.t_alarm_history ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_48.t_alarm_real ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_48.t_alarm_shield ADD dossKey VARCHAR(255) not null DEFAULT '-';

alter TABLE ship_82.t_alarm_history ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_82.t_alarm_real ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_82.t_alarm_shield ADD dossKey VARCHAR(255) not null DEFAULT '-';

alter TABLE ship_83.t_alarm_history ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_83.t_alarm_real ADD dossKey VARCHAR(255) not null DEFAULT '-';
alter TABLE ship_83.t_alarm_shield ADD dossKey VARCHAR(255) not null DEFAULT '-';