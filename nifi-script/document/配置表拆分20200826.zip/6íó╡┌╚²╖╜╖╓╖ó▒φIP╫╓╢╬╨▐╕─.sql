delimiter //  # 定义//为一句sql的结束标志，取消;的所代表的意义
drop procedure if exists test;  # 如果存在名字为test的procedure则删除
create procedure test()  # 创建（创建函数使用的关键字为function 函数名()）
begin
		# 声明变量
		declare tdis_user_and_password varchar(10);
		declare tdis_user_and_password_down varchar(10);
		declare tdist_freq varchar(10);
		declare tdist_group varchar(10);
		declare tdist_ip_addr varchar(255);
		declare tdist_ip_addr_down varchar(10);
		declare tdist_protocol varchar(10);
		declare tdoss_key int;
		declare tid int;
		declare tsid int;
    declare flag int default 0; # 定义循环结果的标志位
		declare str VARCHAR(255); # 定义分割特殊字段的暂存字段
    # 将查询结果赋值给游标
    declare tstream_rule cursor for select id,sid,doss_key,dist_protocol,dist_ip_addr_down,dist_ip,dist_group,dist_freq,dis_user_and_password_down from tstream_rule_other_distributions; 
    # 为下面while循环建立一个退出标志，当游标遍历完后将flag的值设置为1
    declare continue handler for not found set flag=1;
    open tstream_rule;  # 打开游标
    # 将游标中的值赋给定义好的变量，实现for循环的要点
        fetch tstream_rule into tid,tsid,tdoss_key,tdist_protocol,tdist_ip_addr_down,tdist_ip_addr,tdist_group,tdist_freq,tdis_user_and_password_down;
        while flag <> 1 do
						# 在T-SQL中，局部变量必须以@作为前缀，声明方式set，select还有点差别
            IF (LOCATE(",",tdist_ip_addr)>0) THEN
							 #得到第一个分割字段
							 set @temp_ip = SUBSTRING_INDEX(tdist_ip_addr,",",1);
							 #得到剩余的分割字段
							 set @temp_port = SUBSTRING(tdist_ip_addr,LOCATE(",",tdist_ip_addr)+1);
							 # 根据id的唯一性，利用当前查询到的记录中的字段值来实现更新
							 update tstream_rule_other_distributions set dist_ip=@temp_ip,dist_port=@temp_port where id = tid and sid = tsid;
						END IF;
							# 游标往后移
							fetch tstream_rule into tid,tsid,tdoss_key,tdist_protocol,tdist_ip_addr_down,tdist_ip_addr,tdist_group,tdist_freq,tdis_user_and_password_down;
        end while;
        #select * from temp_table;
    close tstream_rule;  # 关闭游标
end
//
delimiter ;  # 重新定义;为一句sql的结束标志，取消//的所代表的意义
call test(); # 调用
select * from tstream_rule_other_distributions; # 测试结果
